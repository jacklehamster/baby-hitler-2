gameConfig.scenes.push(
	{
		name: "inside-tavern",
		onScene: game => {
		},
		sprites: [
		],
	},
);