game.addScene(
	{
		name: "inside-tavern",
		onScene: game => {
		},
		sprites: [
		],
	},
);