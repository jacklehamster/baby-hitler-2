# baby-hitler-2
Repo for the game "Where in space is Baby Hitler"
